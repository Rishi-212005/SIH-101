const db = require("../db");
const bcrypt = require("bcryptjs");

exports.registerUser = (req, res) => {
  const { role, fullName, email, phone, password, department, skills } = req.body;

  if (!fullName || !email || !phone || !password) {
    return res.status(400).json({ message: "All required fields must be filled" });
  }

  // check if email already exists
  db.query("SELECT * FROM users WHERE email = ?", [email], async (err, results) => {
    if (err) return res.status(500).json({ message: "Database error" });
    if (results.length > 0) {
      return res.status(400).json({ message: "Email already registered" });
    }

    // hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    const sql = `INSERT INTO users (role, fullName, email, phone, password, department, skills) 
                 VALUES (?, ?, ?, ?, ?, ?, ?)`;
    db.query(sql, [role, fullName, email, phone, hashedPassword, department, skills], (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: "Failed to register user" });
      }
      res.status(201).json({ message: "User registered successfully" });
    });
  });
};
